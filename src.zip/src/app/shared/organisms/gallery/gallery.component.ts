import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SectionTitleComponent } from '../../atoms/section-title/section-title.component';
import { GalleryItemComponent } from '../../molecules/gallery-item/gallery-item.component';

@Component({
  selector: 'app-gallery',
  standalone: true,
  imports: [CommonModule, SectionTitleComponent, GalleryItemComponent],
  templateUrl: './gallery.component.html',
})
export class GalleryComponent {
  // TODO: reemplazar por fotos reales en /public/galeria/ cuando las tengan
  photos = [
    { image: 'https://loremflickr.com/500/500/woodenbox,wedding', caption: 'Boda' },
    { image: 'https://loremflickr.com/500/500/woodenbox,rustic', caption: 'Rústica' },
    { image: 'https://loremflickr.com/500/500/woodenbox,crate', caption: 'Caja artesanal' },
    { image: 'https://loremflickr.com/500/500/woodenbox,gift', caption: 'Detalle de regalo' },
    { image: 'https://loremflickr.com/500/500/woodenbox,decor', caption: 'Decorativa' },
    { image: 'https://loremflickr.com/500/500/woodenbox,handmade', caption: 'Hecha a mano' },
  ];
}